<?php
@include 'config.php';

class UserRegistrationManager
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function registerUser($name, $email, $password, $confirmPassword)
    {
        $filter_name = filter_var($name, FILTER_SANITIZE_STRING);
        $name = mysqli_real_escape_string($this->conn, $filter_name);
        $filter_email = filter_var($email, FILTER_SANITIZE_STRING);
        $email = mysqli_real_escape_string($this->conn, $filter_email);

        if (strlen($password) < 8) {
            return 'Password should be at least 8 characters long!';
        } else {
            $pass = mysqli_real_escape_string($this->conn, md5($password));

            $select_users = mysqli_query($this->conn, "SELECT * FROM `users` WHERE email = '$email'") or die('query failed');

            if (mysqli_num_rows($select_users) > 0) {
                return 'User already exists!';
            } else {
                if ($pass != mysqli_real_escape_string($this->conn, md5($confirmPassword))) {
                    return 'Confirm password not matched!';
                } else {
                    mysqli_query($this->conn, "INSERT INTO `users`(name, email, password) VALUES('$name', '$email', '$pass')") or die('query failed');
                    return 'Registered successfully!';
                }
            }
        }
    }
}

$userRegistrationManager = new UserRegistrationManager($conn);
$message = '';

if (isset($_POST['submit'])) {
    $message = $userRegistrationManager->registerUser($_POST['name'], $_POST['email'], $_POST['pass'], $_POST['cpass']);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .input-container {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .input-container i {
            margin-right: 10px;
            font-size: 20px;
        }

        .box {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #007bff;
            border-radius: 4px;
            outline: none;
        }
    </style>
</head>

<body>

    <section class="form-container">
        <form action="" method="post">
            <h3><i class="fas fa-user-plus"></i> Register Now</h3>
            <?php
            if (!empty($message)) {
                echo '
                    <div class="message">
                        <span>' . $message . '</span>
                        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
                    </div>
                    ';
            }
            ?>
            <div class="input-container">
                <i class="fas fa-user"></i>
                <input type="text" name="name" class="box" placeholder="Enter your username" required>
            </div>
            <div class="input-container">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" class="box" placeholder="Enter your email" required>
            </div>
            <div class="input-container">
                <i class="fas fa-lock"></i>
                <input type="password" name="pass" class="box" placeholder="Enter your password" required>
            </div>
            <div class="input-container">
                <i class="fas fa-lock"></i>
                <input type="password" name="cpass" class="box" placeholder="Confirm your password" required>
            </div>
            <input type="submit" class="btn" name="submit" value="Register Now">
            <p>Already have an account? <a href="login.php">Login now</a></p>
        </form>
    </section>

    <script src="js/script.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>

</html>
