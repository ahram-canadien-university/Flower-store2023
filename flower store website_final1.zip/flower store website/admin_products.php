<?php

@include 'config.php';

session_start();

class AdminProductManager
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function addProduct($name, $price, $details, $image)
    {
        $name = mysqli_real_escape_string($this->conn, $name);
        $price = mysqli_real_escape_string($this->conn, $price);
        $details = mysqli_real_escape_string($this->conn, $details);
        $image_name = $_FILES[$image]['name'];
        $image_size = $_FILES[$image]['size'];
        $image_tmp_name = $_FILES[$image]['tmp_name'];
        $image_folder = 'uploaded_img/' . $image_name;

        $select_product_name = mysqli_query($this->conn, "SELECT name FROM `products` WHERE name = '$name'") or die('query failed');

        if (mysqli_num_rows($select_product_name) > 0) {
            return 'Product name already exists!';
        } else {
            $insert_product = mysqli_query($this->conn, "INSERT INTO `products`(name, details, price, image) VALUES('$name', '$details', '$price', '$image_name')") or die('query failed');

            if ($insert_product) {
                if ($image_size > 2000000) {
                    return 'Image size is too large!';
                } else {
                    move_uploaded_file($image_tmp_name, $image_folder);
                    return 'Product added successfully!';
                }
            }
        }
    }

    public function deleteProduct($delete_id)
    {
        $select_delete_image = mysqli_query($this->conn, "SELECT image FROM `products` WHERE id = '$delete_id'") or die('query failed');
        $fetch_delete_image = mysqli_fetch_assoc($select_delete_image);
        unlink('uploaded_img/' . $fetch_delete_image['image']);
        mysqli_query($this->conn, "DELETE FROM `products` WHERE id = '$delete_id'") or die('query failed');
        mysqli_query($this->conn, "DELETE FROM `wishlist` WHERE pid = '$delete_id'") or die('query failed');
        mysqli_query($this->conn, "DELETE FROM `cart` WHERE pid = '$delete_id'") or die('query failed');
        header('location:admin_products.php');
    }

    public function getAllProducts()
    {
        $products = [];

        $select_products = mysqli_query($this->conn, "SELECT * FROM `products`") or die('query failed');
        if (mysqli_num_rows($select_products) > 0) {
            while ($fetch_products = mysqli_fetch_assoc($select_products)) {
                $products[] = $fetch_products;
            }
        }

        return $products;
    }
}

// Database Connection
$conn = mysqli_connect('localhost', 'root', '', 'shop_db') or die('connection failed');

// Check connection
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}

// Initialize the class with the database connection
$adminProductManager = new AdminProductManager($conn);

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:login.php');
}

$message = '';

if (isset($_POST['add_product'])) {
    $message = $adminProductManager->addProduct($_POST['name'], $_POST['price'], $_POST['details'], 'image');
}

if (isset($_GET['delete'])) {
    $adminProductManager->deleteProduct($_GET['delete']);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>products</title>

    <!-- font awesome cdn link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- custom admin css file link -->
    <link rel="stylesheet" href="css/admin_style.css">
</head>

<body>

    <?php @include 'admin_header.php'; ?>

    <section class="add-products">

        <form action="" method="POST" enctype="multipart/form-data">
            <h3>add new product</h3>
            <input type="text" class="box" required placeholder="enter product name" name="name">
            <input type="number" min="0" class="box" required placeholder="enter product price" name="price">
            <textarea name="details" class="box" required placeholder="enter product details" cols="30" rows="10"></textarea>
            <input type="file" accept="image/jpg, image/jpeg, image/png" required class="box" name="image">
            <input type="submit" value="add product" name="add_product" class="btn">
        </form>

        <?php
        if (!empty($message)) {
            echo '<div class="message">
                    <span>' . $message . '</span>
                    <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
                  </div>';
        }
        ?>

    </section>

    <section class="show-products">

        <div class="box-container">

            <?php
            $products = $adminProductManager->getAllProducts();
            if (!empty($products)) {
                foreach ($products as $product) {
            ?>
                    <div class="box">
                        <div class="price"><?php echo $product['price']; ?> EGP</div>
                        <img class="image" src="uploaded_img/<?php echo $product['image']; ?>" alt="">
                        <div class="name"><?php echo $product['name']; ?></div>
                        <div class="details"><?php echo $product['details']; ?></div>
                        <a href="admin_update_product.php?update=<?php echo $product['id']; ?>" class="option-btn">update</a>
                        <a href="admin_products.php?delete=<?php echo $product['id']; ?>" class="delete-btn" onclick="return confirm('delete this product?');">delete</a>
                    </div>
            <?php
                }
            } else {
                echo '<p class="empty">no products added yet!</p>';
            }
            ?>
        </div>

    </section>

    <script src="js/admin_script.js"></script>

</body>

</html>
