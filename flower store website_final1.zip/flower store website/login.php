<?php

@include 'config.php';

session_start();

class UserLoginManager
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function loginUser($email, $password)
    {
        $filter_email = filter_var($email, FILTER_SANITIZE_STRING);
        $email = mysqli_real_escape_string($this->conn, $filter_email);
        $filter_pass = filter_var($password, FILTER_SANITIZE_STRING);
        $pass = mysqli_real_escape_string($this->conn, md5($filter_pass));

        $select_users = mysqli_query($this->conn, "SELECT * FROM `users` WHERE email = '$email' AND password = '$pass'") or die('query failed');

        if (mysqli_num_rows($select_users) > 0) {
            $row = mysqli_fetch_assoc($select_users);

            if ($row['user_type'] == 'admin') {
                $_SESSION['admin_name'] = $row['name'];
                $_SESSION['admin_email'] = $row['email'];
                $_SESSION['admin_id'] = $row['id'];
                header('location: admin_products.php');
            } elseif ($row['user_type'] == 'user') {
                $_SESSION['user_name'] = $row['name'];
                $_SESSION['user_email'] = $row['email'];
                $_SESSION['user_id'] = $row['id'];
                header('location: home.php');
            } else {
                return 'No user found!';
            }
        } else {
            return 'Incorrect email or password!';
        }
    }
}

$message = '';
$userLoginManager = new UserLoginManager($conn);

if (isset($_POST['submit'])) {
    $message = $userLoginManager->loginUser($_POST['email'], $_POST['pass']);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        i {
            margin-right: 10px;
            font-size: 20px;
        }

        .input-container {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .box {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #007bff;
            border-radius: 4px;
            outline: none;
        }
    </style>
</head>

<body>

    <?php
    if (!empty($message)) {
        echo '
      <div class="message">
         <span>' . $message . '</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
    }
    ?>

    <section class="form-container">
        <form action="" method="post">
            <h3><i class="fas fa-sign-in-alt icon"></i> Login Now</h3>
            <div class="input-container">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" class="box" placeholder="Enter your email" required>
            </div>
            <div class="input-container">
                <i class="fas fa-lock"></i>
                <input type="password" name="pass" class="box" placeholder="Enter your password" required>
            </div>
            <input type="submit" class="btn" name="submit" value="Login Now">
            <p>Don't have an account? <a href="register.php">Register now</a></p>
        </form>
    </section>

</body>

</html>
